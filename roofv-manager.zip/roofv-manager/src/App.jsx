import { useEffect, useMemo, useState } from "react";
import {
  LogOut, Plus, Trash2, Clock, Flame, CheckCircle2,
  Briefcase, TimerReset, Play, Pause, Download,
  ShieldAlert, Bug, NotebookPen, Activity, Search,
  Target, LayoutDashboard, Users, RefreshCcw
} from "lucide-react";

const ADMINS = [
  { username: "Atilla", password: "120824sS", role: "Founder / Lead" },
  { username: "44mlx", password: "44mlx44sS", role: "Manager" },
  { username: "Utku", password: "düzcetutkudüzce", role: "Manager" }
];

const statuses = ["Bekliyor", "Devam Ediyor", "Testte", "Tamamlandı"];
const priorities = ["Düşük", "Orta", "Yüksek", "Acil"];
const risks = ["Normal", "Gecikebilir", "Kritik", "Projeyi Blokluyor"];
const projectTypes = ["FiveM", "Web", "Mobil", "Discord Bot", "Tasarım", "Genel"];

const initialData = {
  tasks: [],
  bugs: [],
  notes: [],
  activities: [],
  sprints: [
    {
      id: "default-sprint",
      title: "RoofV Nexus ortak veri sistemi",
      owner: "Atilla",
      deadline: "Bu hafta",
      progress: 75
    }
  ]
};

async function getDataFromServer() {
  const res = await fetch("/.netlify/functions/roofv-data", {
    cache: "no-store"
  });

  if (!res.ok) {
    throw new Error("Veri alınamadı.");
  }

  return await res.json();
}

async function saveDataToServer(data) {
  const res = await fetch("/.netlify/functions/roofv-data", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(data)
  });

  if (!res.ok) {
    throw new Error("Veri kaydedilemedi.");
  }

  return await res.json();
}

export default function App() {
  const [user, setUser] = useState(() => JSON.parse(localStorage.getItem("roofv_user")) || null);
  const [data, setData] = useState(initialData);
  const [activePage, setActivePage] = useState("dashboard");
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [error, setError] = useState("");

  async function loadServerData() {
    try {
      setError("");
      setLoading(true);
      const serverData = await getDataFromServer();
      setData(serverData || initialData);
    } catch (err) {
      setError("Ortak veri yüklenemedi. Netlify deploy ve function ayarlarını kontrol et.");
    } finally {
      setLoading(false);
    }
  }

  async function commitData(updater, activityText) {
    setData(prev => {
      const next = typeof updater === "function" ? updater(prev) : updater;

      const finalData = activityText
        ? {
            ...next,
            activities: [
              {
                id: crypto.randomUUID(),
                text: activityText,
                user: user?.username || "System",
                date: new Date().toLocaleString("tr-TR")
              },
              ...(next.activities || [])
            ]
          }
        : next;

      setSyncing(true);
      saveDataToServer(finalData)
        .then(() => setError(""))
        .catch(() => setError("Veri Netlify’a kaydedilemedi."))
        .finally(() => setSyncing(false));

      return finalData;
    });
  }

  useEffect(() => {
    loadServerData();
  }, []);

  useEffect(() => {
    localStorage.setItem("roofv_user", JSON.stringify(user));
  }, [user]);

  if (!user) return <Login onLogin={setUser} />;

  const menuItems = [
    { id: "dashboard", label: "Panel", icon: <LayoutDashboard size={18} /> },
    { id: "tasks", label: "Görev", icon: <Briefcase size={18} /> },
    { id: "bugs", label: "Bug", icon: <Bug size={18} /> },
    { id: "risks", label: "Risk", icon: <ShieldAlert size={18} /> },
    { id: "notes", label: "Not", icon: <NotebookPen size={18} /> },
    { id: "team", label: "Ekip", icon: <Users size={18} /> }
  ];

  if (loading) {
    return (
      <main className="login">
        <div className="login-card">
          <h1>RoofV Nexus</h1>
          <p>Ortak veriler yükleniyor...</p>
        </div>
      </main>
    );
  }

  return (
    <main className="app">
      <aside className="sidebar">
        <div>
          <h1>RoofV</h1>
          <p>Nexus Command System</p>
        </div>

        <nav>
          {menuItems.map(item => (
            <button
              key={item.id}
              className={activePage === item.id ? "active" : ""}
              onClick={() => setActivePage(item.id)}
            >
              {item.icon}
              {item.label}
            </button>
          ))}
        </nav>

        <button
          className="logout"
          onClick={() => {
            localStorage.removeItem("roofv_user");
            setUser(null);
          }}
        >
          <LogOut size={17} /> Çıkış
        </button>
      </aside>

      <section className="content">
        <header className="topbar">
          <div>
            <h2>RoofV Nexus</h2>
            <p>
              Hoş geldin, {user.username}
              {syncing ? " · Kaydediliyor..." : " · Ortak veri aktif"}
            </p>
          </div>

          <div className="search">
            <Search size={17} />
            <input
              placeholder="Görev ara..."
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>

          <div className="top-actions">
            <button className="ghost-btn" onClick={loadServerData}>
              <RefreshCcw size={17} /> Yenile
            </button>

            <button className="export-btn" onClick={() => exportJSON(data)}>
              <Download size={17} /> Yedek
            </button>
          </div>
        </header>

        {error && <div className="error-box">{error}</div>}

        {activePage === "dashboard" && <Dashboard data={data} />}
        {activePage === "tasks" && (
          <Tasks data={data} commitData={commitData} user={user} search={search} />
        )}
        {activePage === "bugs" && <Bugs data={data} commitData={commitData} user={user} />}
        {activePage === "risks" && <Risks data={data} />}
        {activePage === "notes" && <Notes data={data} commitData={commitData} user={user} />}
        {activePage === "team" && <Team data={data} />}
      </section>

      <nav className="mobile-nav">
        {menuItems.slice(0, 5).map(item => (
          <button
            key={item.id}
            className={activePage === item.id ? "active" : ""}
            onClick={() => setActivePage(item.id)}
          >
            {item.icon}
            <span>{item.label}</span>
          </button>
        ))}
      </nav>
    </main>
  );
}

function Login({ onLogin }) {
  const [u, setU] = useState("");
  const [p, setP] = useState("");
  const [err, setErr] = useState("");

  function submit(e) {
    e.preventDefault();
    const found = ADMINS.find(a => a.username === u && a.password === p);
    if (!found) return setErr("Kullanıcı adı veya şifre hatalı.");
    onLogin({ username: found.username, role: found.role });
  }

  return (
    <main className="login">
      <form className="login-card" onSubmit={submit}>
        <div className="orb"></div>
        <h1>RoofV Nexus</h1>
        <p>Project & Team Command System</p>

        <input placeholder="Kullanıcı adı" value={u} onChange={e => setU(e.target.value)} />
        <input placeholder="Şifre" type="password" value={p} onChange={e => setP(e.target.value)} />

        {err && <span className="error">{err}</span>}
        <button>Giriş Yap</button>
      </form>
    </main>
  );
}

function Dashboard({ data }) {
  const totalMin = data.tasks.reduce((a, b) => a + Number(b.minutes || 0), 0);
  const done = data.tasks.filter(t => t.status === "Tamamlandı").length;
  const urgent = data.tasks.filter(t => t.priority === "Acil").length;
  const critical = data.tasks.filter(t => t.risk === "Kritik" || t.risk === "Projeyi Blokluyor").length;

  return (
    <>
      <section className="stats">
        <Stat icon={<Briefcase />} title="Toplam Görev" value={data.tasks.length} />
        <Stat icon={<CheckCircle2 />} title="Tamamlanan" value={done} />
        <Stat icon={<Flame />} title="Acil" value={urgent} />
        <Stat icon={<ShieldAlert />} title="Kritik Risk" value={critical} />
        <Stat icon={<Clock />} title="Toplam Süre" value={`${Math.floor(totalMin / 60)}s ${totalMin % 60}dk`} />
        <Stat icon={<Bug />} title="Bug" value={data.bugs.length} />
      </section>

      <h3 className="section-title">Sprint Hedefleri</h3>

      <div className="grid">
        {data.sprints.map(s => (
          <article className="card" key={s.id}>
            <Target />
            <h3>{s.title}</h3>
            <p>Sorumlu: {s.owner}</p>
            <p>Deadline: {s.deadline}</p>
            <div className="bar">
              <span style={{ width: `${s.progress}%` }}></span>
            </div>
            <b>%{s.progress}</b>
          </article>
        ))}
      </div>

      <h3 className="section-title">Son Aktiviteler</h3>

      <div className="activity-list">
        {data.activities.length === 0 && <p className="empty">Henüz aktivite yok.</p>}
        {data.activities.slice(0, 8).map(a => (
          <div className="activity" key={a.id}>
            <Activity size={16} />
            <span>{a.user}: {a.text}</span>
            <small>{a.date}</small>
          </div>
        ))}
      </div>
    </>
  );
}

function Tasks({ data, commitData, user, search }) {
  const [form, setForm] = useState({
    title: "",
    description: "",
    project: "FiveM",
    assignedTo: "Atilla",
    priority: "Orta",
    risk: "Normal",
    deadline: ""
  });

  const filtered = data.tasks.filter(t =>
    t.title.toLowerCase().includes(search.toLowerCase())
  );

  function addTask(e) {
    e.preventDefault();
    if (!form.title.trim()) return;

    const task = {
      ...form,
      id: crypto.randomUUID(),
      status: "Bekliyor",
      minutes: 0,
      comments: [],
      timerStart: null,
      assignedBy: user.username
    };

    commitData(
      prev => ({ ...prev, tasks: [task, ...(prev.tasks || [])] }),
      `"${form.title}" görevini oluşturdu`
    );

    setForm({ ...form, title: "", description: "", deadline: "" });
  }

  function update(id, patch) {
    commitData(prev => ({
      ...prev,
      tasks: prev.tasks.map(t => (t.id === id ? { ...t, ...patch } : t))
    }));
  }

  function remove(id) {
    commitData(
      prev => ({ ...prev, tasks: prev.tasks.filter(t => t.id !== id) }),
      "Bir görevi sildi"
    );
  }

  return (
    <>
      <form className="panel" onSubmit={addTask}>
        <h3>Yeni Görev</h3>

        <div className="form-grid">
          <input
            placeholder="Görev başlığı"
            value={form.title}
            onChange={e => setForm({ ...form, title: e.target.value })}
          />

          <select value={form.assignedTo} onChange={e => setForm({ ...form, assignedTo: e.target.value })}>
            {ADMINS.map(a => <option key={a.username}>{a.username}</option>)}
          </select>

          <select value={form.project} onChange={e => setForm({ ...form, project: e.target.value })}>
            {projectTypes.map(p => <option key={p}>{p}</option>)}
          </select>

          <select value={form.priority} onChange={e => setForm({ ...form, priority: e.target.value })}>
            {priorities.map(p => <option key={p}>{p}</option>)}
          </select>

          <select value={form.risk} onChange={e => setForm({ ...form, risk: e.target.value })}>
            {risks.map(r => <option key={r}>{r}</option>)}
          </select>

          <input
            type="date"
            value={form.deadline}
            onChange={e => setForm({ ...form, deadline: e.target.value })}
          />
        </div>

        <textarea
          placeholder="Açıklama"
          value={form.description}
          onChange={e => setForm({ ...form, description: e.target.value })}
        />

        <button><Plus size={17} /> Görev Ekle</button>
      </form>

      <section className="kanban">
        {statuses.map(status => (
          <div className="column" key={status}>
            <h3>{status}</h3>

            {filtered.filter(t => t.status === status).length === 0 && (
              <p className="empty">Görev yok.</p>
            )}

            {filtered.filter(t => t.status === status).map(task => (
              <TaskCard key={task.id} task={task} update={update} remove={remove} />
            ))}
          </div>
        ))}
      </section>
    </>
  );
}

function TaskCard({ task, update, remove }) {
  const [comment, setComment] = useState("");

  const isDeadlineClose = useMemo(() => {
    if (!task.deadline) return false;
    const today = new Date();
    const deadline = new Date(task.deadline);
    const diff = Math.ceil((deadline - today) / (1000 * 60 * 60 * 24));
    return diff <= 2 && task.status !== "Tamamlandı";
  }, [task.deadline, task.status]);

  function toggleTimer() {
    if (task.timerStart) {
      const diff = Math.floor((Date.now() - task.timerStart) / 60000);
      update(task.id, {
        timerStart: null,
        minutes: task.minutes + Math.max(diff, 1)
      });
    } else {
      update(task.id, {
        timerStart: Date.now(),
        status: "Devam Ediyor"
      });
    }
  }

  function addComment() {
    if (!comment.trim()) return;

    update(task.id, {
      comments: [
        ...(task.comments || []),
        {
          id: crypto.randomUUID(),
          text: comment,
          date: new Date().toLocaleString("tr-TR")
        }
      ]
    });

    setComment("");
  }

  return (
    <article className={`task ${task.priority === "Acil" ? "urgent" : ""} ${isDeadlineClose ? "deadline-warning" : ""}`}>
      <div className="task-head">
        <span className="badge">{task.project}</span>
        <button className="icon" onClick={() => remove(task.id)}>
          <Trash2 size={15} />
        </button>
      </div>

      <h4>{task.title}</h4>
      <p>{task.description || "Açıklama yok."}</p>

      <div className="meta">
        <span>Veren: {task.assignedBy}</span>
        <span>Alan: {task.assignedTo}</span>
        <span>Öncelik: {task.priority}</span>
        <span>Risk: {task.risk}</span>
        <span>Deadline: {task.deadline || "Yok"}</span>
      </div>

      <select value={task.status} onChange={e => update(task.id, { status: e.target.value })}>
        {statuses.map(s => <option key={s}>{s}</option>)}
      </select>

      <div className="timer">
        <button onClick={toggleTimer}>
          {task.timerStart ? <Pause size={15} /> : <Play size={15} />}
          {task.timerStart ? "Durdur" : "Başlat"}
        </button>

        <span>
          <TimerReset size={15} />
          {Math.floor(task.minutes / 60)}s {task.minutes % 60}dk
        </span>
      </div>

      <div className="comments">
        {(task.comments || []).map(c => (
          <small key={c.id}>💬 {c.text}</small>
        ))}

        <div className="comment-row">
          <input
            placeholder="Yorum yaz..."
            value={comment}
            onChange={e => setComment(e.target.value)}
          />
          <button type="button" onClick={addComment}>Ekle</button>
        </div>
      </div>
    </article>
  );
}

function Bugs({ data, commitData, user }) {
  const [bug, setBug] = useState({
    title: "",
    project: "FiveM",
    level: "Orta",
    assignedTo: "Atilla"
  });

  function add(e) {
    e.preventDefault();
    if (!bug.title.trim()) return;

    const newBug = {
      ...bug,
      id: crypto.randomUUID(),
      reporter: user.username,
      createdAt: new Date().toLocaleString("tr-TR")
    };

    commitData(
      prev => ({ ...prev, bugs: [newBug, ...(prev.bugs || [])] }),
      `Bug ekledi: ${bug.title}`
    );

    setBug({ ...bug, title: "" });
  }

  return (
    <>
      <form className="panel" onSubmit={add}>
        <h3>Bug Report</h3>

        <div className="form-grid bug-grid">
          <input
            placeholder="Bug başlığı"
            value={bug.title}
            onChange={e => setBug({ ...bug, title: e.target.value })}
          />

          <select value={bug.project} onChange={e => setBug({ ...bug, project: e.target.value })}>
            {projectTypes.map(p => <option key={p}>{p}</option>)}
          </select>

          <select value={bug.level} onChange={e => setBug({ ...bug, level: e.target.value })}>
            {priorities.map(p => <option key={p}>{p}</option>)}
          </select>

          <select value={bug.assignedTo} onChange={e => setBug({ ...bug, assignedTo: e.target.value })}>
            {ADMINS.map(a => <option key={a.username}>{a.username}</option>)}
          </select>
        </div>

        <button><Bug size={17} /> Bug Ekle</button>
      </form>

      <div className="grid">
        {data.bugs.length === 0 && <p className="empty">Henüz bug yok.</p>}

        {data.bugs.map(b => (
          <article className="card" key={b.id}>
            <Bug />
            <h3>{b.title}</h3>
            <p>Proje: {b.project}</p>
            <p>Seviye: {b.level}</p>
            <p>Sorumlu: {b.assignedTo}</p>
            <small>Ekleyen: {b.reporter}</small>
          </article>
        ))}
      </div>
    </>
  );
}

function Risks({ data }) {
  const risky = data.tasks.filter(t => t.risk !== "Normal");

  return (
    <div className="grid">
      {risky.length === 0 && <p className="empty">Şu an riskli görev yok.</p>}

      {risky.map(t => (
        <article className="card danger" key={t.id}>
          <ShieldAlert />
          <h3>{t.title}</h3>
          <p>Risk: {t.risk}</p>
          <p>Proje: {t.project}</p>
          <p>Sorumlu: {t.assignedTo}</p>
        </article>
      ))}
    </div>
  );
}

function Notes({ data, commitData, user }) {
  const [text, setText] = useState("");

  function addNote(e) {
    e.preventDefault();
    if (!text.trim()) return;

    const note = {
      id: crypto.randomUUID(),
      text,
      author: user.username,
      date: new Date().toLocaleString("tr-TR")
    };

    commitData(
      prev => ({ ...prev, notes: [note, ...(prev.notes || [])] }),
      "Karar defterine not ekledi"
    );

    setText("");
  }

  return (
    <>
      <form className="panel" onSubmit={addNote}>
        <h3>Karar Defteri</h3>
        <textarea
          placeholder="Alınan karar / toplantı notu..."
          value={text}
          onChange={e => setText(e.target.value)}
        />
        <button><NotebookPen size={17} /> Not Ekle</button>
      </form>

      <div className="grid">
        {data.notes.length === 0 && <p className="empty">Henüz not yok.</p>}

        {data.notes.map(n => (
          <article className="card" key={n.id}>
            <NotebookPen />
            <p>{n.text}</p>
            <small>{n.author} — {n.date}</small>
          </article>
        ))}
      </div>
    </>
  );
}

function Team({ data }) {
  return (
    <div className="grid">
      {ADMINS.map(admin => {
        const tasks = data.tasks.filter(t => t.assignedTo === admin.username);
        const done = tasks.filter(t => t.status === "Tamamlandı").length;
        const min = tasks.reduce((a, b) => a + Number(b.minutes || 0), 0);

        return (
          <article className="card" key={admin.username}>
            <Users />
            <h3>{admin.username}</h3>
            <p>{admin.role}</p>
            <p>Görev: {tasks.length}</p>
            <p>Tamamlanan: {done}</p>
            <p>Süre: {Math.floor(min / 60)}s {min % 60}dk</p>
          </article>
        );
      })}
    </div>
  );
}

function Stat({ icon, title, value }) {
  return (
    <article className="stat">
      {icon}
      <p>{title}</p>
      <h3>{value}</h3>
    </article>
  );
}

function exportJSON(data) {
  const blob = new Blob([JSON.stringify(data, null, 2)], {
    type: "application/json"
  });

  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "roofv-nexus-backup.json";
  a.c