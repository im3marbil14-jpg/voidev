import { getStore } from "@netlify/blobs";

const defaultData = {
  tasks: [],
  bugs: [],
  notes: [],
  activities: [],
  sprints: [
    {
      id: "default-sprint",
      title: "RoofV Nexus ortak veri sistemi",
      owner: "Atilla",
      deadline: "Bu hafta",
      progress: 75
    }
  ]
};

export default async function handler(req) {
  const store = getStore("roofv-nexus-store");

  if (req.method === "GET") {
    const data = await store.get("main-data", { type: "json" });

    return Response.json(data || defaultData, {
      headers: {
        "Cache-Control": "no-store"
      }
    });
  }

  if (req.method === "POST") {
    const body = await req.json();
    await store.setJSON("main-data", body);

    return Response.json({
      success: true,
      data: body
    });
  }

  return new Response("Method not allowed", { status: 405 });
}